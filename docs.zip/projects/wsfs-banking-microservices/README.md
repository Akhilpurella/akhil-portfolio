# WSFS Banking Microservices
Spring Boot + Kafka; Oracle SQL; includes a sample health endpoint.
