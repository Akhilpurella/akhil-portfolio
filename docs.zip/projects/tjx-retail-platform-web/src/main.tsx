import React from 'react'
import { createRoot } from 'react-dom/client'

function App() {
  return (
    <div style={{ padding: 24, maxWidth: 960, margin: '0 auto' }}>
      <h1>TJX Retail Platform</h1>
      <p>Starter dashboard. Replace mock data with your API.</p>
    </div>
  )
}

createRoot(document.getElementById('root')!).render(<App />)
