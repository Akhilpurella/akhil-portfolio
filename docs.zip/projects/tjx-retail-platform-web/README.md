# TJX Retail Platform Web
Vite + React starter; replace mock UI with your API.
