# Newgen Workflow Automation
React dashboards + Spring Boot + ActiveMQ + MongoDB on GCP.
