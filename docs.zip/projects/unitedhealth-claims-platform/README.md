# UnitedHealth Claims Platform
Angular portals + Spring Boot + Kafka Streams on Azure (HIPAA-aware patterns).
