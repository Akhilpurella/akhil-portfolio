# Infinite HR/Finance Portal
React + Spring Boot microservices with Kafka and MySQL on AWS.
